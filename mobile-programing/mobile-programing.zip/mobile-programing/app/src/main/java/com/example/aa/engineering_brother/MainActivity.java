package com.example.aa.engineering_brother;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.design.widget.TabLayout;
import android.os.Bundle;
import android.view.View;

import com.example.aa.engineering_brother.fragment.Fragment_One;
import com.example.aa.engineering_brother.fragment.Fragment_Three;
import com.example.aa.engineering_brother.fragment.Fragment_Two;

public class MainActivity extends AppCompatActivity {
    private ViewPager mViewPager;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mViewPager =(ViewPager) findViewById(R.id.pager);

        MyPagerAdapter myPagerAdapter = new MyPagerAdapter(
                getSupportFragmentManager()
        );

        mViewPager.setAdapter(myPagerAdapter);

        TabLayout mTab = (TabLayout) findViewById(R.id.tabs);
        mTab.setupWithViewPager(mViewPager);

    }


    private static class MyPagerAdapter extends FragmentPagerAdapter {

        public MyPagerAdapter(FragmentManager fm){
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            switch (position){
                case 0:
                    return Fragment_One.newInstance();
                case 1:
                    return Fragment_Two.newInstance();
                case 2:
                    return Fragment_Three.newInstance();
            }
            return null;
        }

        @Override
        public int getCount() {
            return 3;
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            switch (position){
                case 0:
                    return "컴알못";
                case 1:
                    return "노트북추천";
                case 2:
                    return "사러가기";
                default:
                return null;
            }

        }
    }



    public void onFragmentChanged(int index){
        if(index ==0){
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.parentView,Fragment_One.newInstance())
                    .addToBackStack(null)
                    .commit();
        }
    }

}
