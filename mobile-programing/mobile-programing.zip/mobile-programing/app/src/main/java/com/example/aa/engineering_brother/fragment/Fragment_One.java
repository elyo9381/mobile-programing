package com.example.aa.engineering_brother.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.aa.engineering_brother.R;

/**
 */
public class Fragment_One extends Fragment {


    public Fragment_One() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_fragment__one, container, false);
        return view;
    }

    public static Fragment_One newInstance() {
        Bundle args = new Bundle();
        Fragment_One fragment_one = new Fragment_One();
        fragment_one.setArguments(args);
        return fragment_one;
    }


}
